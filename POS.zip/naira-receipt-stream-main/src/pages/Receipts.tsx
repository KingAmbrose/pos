import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "@/components/Layout";
import ReceiptCard from "@/components/ReceiptCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Filter, Plus } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const Receipts = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const mockReceipts = [
    {
      id: "RCP-001234",
      amount: "45,000",
      date: "Nov 2, 2025",
      time: "10:30 AM",
      customerName: "Adebayo Ogunleye",
      paymentMethod: "Card",
      status: "completed" as const,
    },
    {
      id: "RCP-001235",
      amount: "12,500",
      date: "Nov 2, 2025",
      time: "11:15 AM",
      customerName: "Chioma Nwosu",
      paymentMethod: "Bank Transfer",
      status: "completed" as const,
    },
    {
      id: "RCP-001236",
      amount: "78,900",
      date: "Nov 2, 2025",
      time: "2:45 PM",
      customerName: "Ibrahim Musa",
      paymentMethod: "Card",
      status: "pending" as const,
    },
    {
      id: "RCP-001237",
      amount: "5,200",
      date: "Nov 1, 2025",
      time: "4:20 PM",
      customerName: "Blessing Okoro",
      paymentMethod: "Cash",
      status: "completed" as const,
    },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">Receipts</h1>
            <p className="text-muted-foreground">
              Manage and view all digital receipts
            </p>
          </div>
          <Button className="gap-2" onClick={() => navigate("/receipts/new")}>
            <Plus className="h-4 w-4" />
            New Receipt
          </Button>
        </div>

        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by receipt ID, customer name..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select defaultValue="all">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            More Filters
          </Button>
        </div>

        <div className="space-y-4">
          {mockReceipts.map((receipt) => (
            <ReceiptCard key={receipt.id} {...receipt} />
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Receipts;
