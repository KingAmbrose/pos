import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Download, Printer, Share2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useReactToPrint } from "react-to-print";

interface Receipt {
  id: string;
  receipt_number: string;
  customer_name: string;
  customer_email: string | null;
  customer_phone: string | null;
  payment_method: string;
  subtotal: number;
  tax_rate: number;
  tax_amount: number;
  total: number;
  created_at: string;
}

interface ReceiptItem {
  id: string;
  item_name: string;
  quantity: number;
  price: number;
  total: number;
}

const ReceiptView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const [items, setItems] = useState<ReceiptItem[]>([]);
  const [loading, setLoading] = useState(true);
  const receiptRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchReceipt();
  }, [id]);

  const fetchReceipt = async () => {
    try {
      const { data: receiptData, error: receiptError } = await supabase
        .from('receipts')
        .select('*')
        .eq('id', id)
        .single();

      if (receiptError) throw receiptError;

      const { data: itemsData, error: itemsError } = await supabase
        .from('receipt_items')
        .select('*')
        .eq('receipt_id', id);

      if (itemsError) throw itemsError;

      setReceipt(receiptData);
      setItems(itemsData || []);
    } catch (error: any) {
      console.error("Error fetching receipt:", error);
      toast.error("Failed to load receipt");
      navigate("/receipts");
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = useReactToPrint({
    contentRef: receiptRef,
    documentTitle: receipt?.receipt_number || 'Receipt',
  });

  const handleDownload = () => {
    if (receiptRef.current) {
      const printContents = receiptRef.current.innerHTML;
      const originalContents = document.body.innerHTML;
      
      document.body.innerHTML = printContents;
      window.print();
      document.body.innerHTML = originalContents;
      window.location.reload();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading receipt...</div>
      </div>
    );
  }

  if (!receipt) {
    return null;
  }

  const paymentMethods: Record<string, string> = {
    card: "Card Payment",
    cash: "Cash",
    transfer: "Bank Transfer",
    mobile: "Mobile Money"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-6 flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate("/receipts")}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Receipts
          </Button>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePrint}
              className="gap-2"
            >
              <Printer className="h-4 w-4" />
              Print
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDownload}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Download
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Share2 className="h-4 w-4" />
              Share
            </Button>
          </div>
        </div>

        <Card ref={receiptRef} className="p-8 md:p-12 print:shadow-none">
          <div className="text-center mb-8 pb-6 border-b-2 border-primary/20">
            <h1 className="text-3xl font-bold text-primary mb-2">RECEIPT</h1>
            <p className="text-sm text-muted-foreground">Digital Transaction Receipt</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-3">Receipt Details</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Receipt No:</span>
                  <span className="text-sm font-mono font-semibold">{receipt.receipt_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Date:</span>
                  <span className="text-sm">{new Date(receipt.created_at).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Payment Method:</span>
                  <span className="text-sm">{paymentMethods[receipt.payment_method]}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-3">Customer Information</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Name:</span>
                  <span className="text-sm font-semibold">{receipt.customer_name}</span>
                </div>
                {receipt.customer_email && (
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Email:</span>
                    <span className="text-sm">{receipt.customer_email}</span>
                  </div>
                )}
                {receipt.customer_phone && (
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Phone:</span>
                    <span className="text-sm">{receipt.customer_phone}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="font-semibold mb-4 pb-2 border-b">Items Purchased</h3>
            <table className="w-full">
              <thead>
                <tr className="border-b text-sm">
                  <th className="text-left py-2 font-semibold">Item</th>
                  <th className="text-center py-2 font-semibold">Qty</th>
                  <th className="text-right py-2 font-semibold">Price</th>
                  <th className="text-right py-2 font-semibold">Total</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, index) => (
                  <tr key={item.id} className={index !== items.length - 1 ? 'border-b' : ''}>
                    <td className="py-3 text-sm">{item.item_name}</td>
                    <td className="py-3 text-sm text-center">{item.quantity}</td>
                    <td className="py-3 text-sm text-right">₦{item.price.toFixed(2)}</td>
                    <td className="py-3 text-sm text-right font-medium">₦{item.total.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end">
            <div className="w-full md:w-1/2 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal:</span>
                <span className="font-medium">₦{receipt.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tax ({receipt.tax_rate}%):</span>
                <span className="font-medium">₦{receipt.tax_amount.toFixed(2)}</span>
              </div>
              <div className="h-px bg-border my-2"></div>
              <div className="flex justify-between text-lg font-bold">
                <span>Total:</span>
                <span className="text-primary">₦{receipt.total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-6 border-t text-center">
            <p className="text-sm text-muted-foreground">Thank you for your business!</p>
            <p className="text-xs text-muted-foreground mt-2">
              This is a digitally generated receipt. For inquiries, please contact us.
            </p>
          </div>
        </Card>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .print\\:shadow-none, .print\\:shadow-none * {
            visibility: visible;
          }
          .print\\:shadow-none {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
};

export default ReceiptView;
