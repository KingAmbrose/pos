import Layout from "@/components/Layout";
import StatCard from "@/components/StatCard";
import { TrendingUp, Receipt, Users, DollarSign } from "lucide-react";
import { Card } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const Dashboard = () => {
  const salesData = [
    { name: "Mon", sales: 4000 },
    { name: "Tue", sales: 3000 },
    { name: "Wed", sales: 5000 },
    { name: "Thu", sales: 4500 },
    { name: "Fri", sales: 6000 },
    { name: "Sat", sales: 5500 },
    { name: "Sun", sales: 4000 },
  ];

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-4xl font-bold text-foreground mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Overview of your POS transactions and digital receipts
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total Sales"
            value="₦2,450,000"
            icon={DollarSign}
            trend="+12.5% from last week"
            trendUp={true}
          />
          <StatCard
            title="Receipts Issued"
            value="1,234"
            icon={Receipt}
            trend="+8.2% from last week"
            trendUp={true}
          />
          <StatCard
            title="Active Customers"
            value="892"
            icon={Users}
            trend="+3.1% from last week"
            trendUp={true}
          />
          <StatCard
            title="Growth Rate"
            value="15.8%"
            icon={TrendingUp}
            trend="+2.4% from last week"
            trendUp={true}
          />
        </div>

        <Card className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-foreground mb-2">Sales Overview</h2>
            <p className="text-muted-foreground">Weekly sales performance</p>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={salesData}>
              <defs>
                <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(210 100% 45%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(210 100% 45%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
              <YAxis stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "var(--radius)",
                }}
              />
              <Area
                type="monotone"
                dataKey="sales"
                stroke="hsl(210 100% 45%)"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#colorSales)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-6">
            <h2 className="text-xl font-bold text-foreground mb-4">Recent Activity</h2>
            <div className="space-y-4">
              {[
                { action: "Receipt issued", customer: "John Doe", time: "2 minutes ago", amount: "₦15,000" },
                { action: "Receipt issued", customer: "Jane Smith", time: "15 minutes ago", amount: "₦22,500" },
                { action: "Receipt issued", customer: "Mike Johnson", time: "1 hour ago", amount: "₦8,750" },
              ].map((activity, idx) => (
                <div key={idx} className="flex items-center justify-between border-b border-border pb-4 last:border-0 last:pb-0">
                  <div>
                    <p className="font-medium text-foreground">{activity.action}</p>
                    <p className="text-sm text-muted-foreground">{activity.customer} · {activity.time}</p>
                  </div>
                  <p className="font-semibold text-primary">{activity.amount}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-bold text-foreground mb-4">Payment Methods</h2>
            <div className="space-y-3">
              {[
                { method: "Card Payment", percentage: 65, amount: "₦1,592,500" },
                { method: "Bank Transfer", percentage: 25, amount: "₦612,500" },
                { method: "Cash", percentage: 10, amount: "₦245,000" },
              ].map((method, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground font-medium">{method.method}</span>
                    <span className="text-muted-foreground">{method.amount}</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-primary rounded-full"
                      style={{ width: `${method.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
