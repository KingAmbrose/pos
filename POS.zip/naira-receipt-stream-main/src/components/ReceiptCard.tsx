import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Eye, MoreVertical } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ReceiptCardProps {
  id: string;
  amount: string;
  date: string;
  time: string;
  customerName: string;
  paymentMethod: string;
  status: "completed" | "pending" | "failed";
  onClick?: () => void;
}

const ReceiptCard = ({
  id,
  amount,
  date,
  time,
  customerName,
  paymentMethod,
  status,
  onClick,
}: ReceiptCardProps) => {
  const statusColors = {
    completed: "bg-success/10 text-success border-success/20",
    pending: "bg-warning/10 text-warning border-warning/20",
    failed: "bg-destructive/10 text-destructive border-destructive/20",
  };

  return (
    <Card className="p-6 hover:shadow-md transition-all duration-300 cursor-pointer" onClick={onClick}>
      <div className="flex items-center justify-between">
        <div className="space-y-3 flex-1">
          <div className="flex items-center gap-3">
            <h3 className="font-semibold text-lg text-foreground">₦{amount}</h3>
            <Badge className={statusColors[status]} variant="outline">
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Receipt ID</p>
              <p className="font-medium text-foreground">{id}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Customer</p>
              <p className="font-medium text-foreground">{customerName}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Date & Time</p>
              <p className="font-medium text-foreground">{date} at {time}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Payment Method</p>
              <p className="font-medium text-foreground">{paymentMethod}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 ml-4">
          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); }}>
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); }}>
            <Download className="h-4 w-4" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Send via Email</DropdownMenuItem>
              <DropdownMenuItem>Send via SMS</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </Card>
  );
};

export default ReceiptCard;
