import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Receipt, TrendingUp, Users, DollarSign, Plus, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import DashboardNav from "@/components/DashboardNav";
import { Badge } from "@/components/ui/badge";

const Dashboard = () => {
  // Mock data
  const stats = [
    { label: "Today's Sales", value: "₦485,200", change: "+12%", icon: DollarSign, trend: "up" },
    { label: "Receipts Issued", value: "156", change: "+8%", icon: Receipt, trend: "up" },
    { label: "Active Customers", value: "89", change: "+5%", icon: Users, trend: "up" },
    { label: "Avg. Transaction", value: "₦3,110", change: "-2%", icon: TrendingUp, trend: "down" },
  ];

  const recentTransactions = [
    { id: "TXN-001", customer: "Chidi Okeke", amount: "₦15,500", time: "2 mins ago", status: "completed" },
    { id: "TXN-002", customer: "Amina Bello", amount: "₦8,200", time: "15 mins ago", status: "completed" },
    { id: "TXN-003", customer: "Tunde Williams", amount: "₦22,750", time: "32 mins ago", status: "completed" },
    { id: "TXN-004", customer: "Ngozi Eze", amount: "₦4,100", time: "1 hour ago", status: "completed" },
    { id: "TXN-005", customer: "Ibrahim Musa", amount: "₦12,300", time: "2 hours ago", status: "completed" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <main className="container py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back! Here's your business overview</p>
          </div>
          <Link to="/transactions/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Receipt
            </Button>
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.label} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="rounded-lg bg-primary/10 p-3">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <span className={`text-sm font-medium ${stat.trend === 'up' ? 'text-success' : 'text-destructive'}`}>
                    {stat.change}
                  </span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              </Card>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Transactions */}
          <Card className="lg:col-span-2 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Recent Transactions</h2>
              <Link to="/transactions">
                <Button variant="outline" size="sm">View All</Button>
              </Link>
            </div>
            
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search transactions..." className="pl-10" />
            </div>

            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <Link 
                  key={transaction.id} 
                  to={`/transactions/${transaction.id}`}
                  className="block"
                >
                  <div className="flex items-center justify-between p-4 rounded-lg border hover:bg-secondary/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Receipt className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{transaction.customer}</p>
                        <p className="text-sm text-muted-foreground">{transaction.id} • {transaction.time}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <p className="font-semibold">{transaction.amount}</p>
                      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                        {transaction.status}
                      </Badge>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </Card>

          {/* Quick Stats */}
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link to="/transactions/new">
                  <Button className="w-full justify-start" variant="outline">
                    <Receipt className="mr-2 h-4 w-4" />
                    Create Receipt
                  </Button>
                </Link>
                <Link to="/transactions">
                  <Button className="w-full justify-start" variant="outline">
                    <Search className="mr-2 h-4 w-4" />
                    Search Receipts
                  </Button>
                </Link>
                <Link to="/analytics">
                  <Button className="w-full justify-start" variant="outline">
                    <TrendingUp className="mr-2 h-4 w-4" />
                    View Analytics
                  </Button>
                </Link>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
              <h3 className="font-semibold mb-2">Monthly Performance</h3>
              <div className="space-y-4 mt-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-muted-foreground">Revenue Goal</span>
                    <span className="font-medium">68%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-primary rounded-full" style={{ width: "68%" }} />
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <p className="text-2xl font-bold text-primary mb-1">₦3.2M</p>
                  <p className="text-sm text-muted-foreground">This month's revenue</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
