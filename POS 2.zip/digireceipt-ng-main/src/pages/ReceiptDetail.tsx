import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Mail, Printer, Share2 } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import DashboardNav from "@/components/DashboardNav";
import { QRCodeSVG } from "qrcode.react";

const ReceiptDetail = () => {
  const { id } = useParams();

  // Mock data
  const receipt = {
    id: id || "TXN-001",
    customer: "Chidi Okeke",
    email: "chidi@email.com",
    phone: "+234 803 123 4567",
    date: "January 15, 2025",
    time: "14:30:25",
    amount: "₦15,500",
    paymentMethod: "Card Payment",
    status: "completed",
    items: [
      { name: "Product A", quantity: 2, price: "₦5,500", total: "₦11,000" },
      { name: "Product B", quantity: 1, price: "₦4,500", total: "₦4,500" },
    ],
    subtotal: "₦15,500",
    tax: "₦0",
    total: "₦15,500",
    merchant: {
      name: "ABC Electronics Ltd",
      address: "123 Ikeja Road, Lagos",
      phone: "+234 1 234 5678",
      email: "info@abcelectronics.com",
    },
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <main className="container py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to="/transactions">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">Receipt Details</h1>
            <p className="text-muted-foreground">Transaction ID: {receipt.id}</p>
          </div>
          <Badge variant="outline" className="bg-success/10 text-success border-success/20">
            {receipt.status}
          </Badge>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-3 mb-6">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Download PDF
          </Button>
          <Button variant="outline">
            <Mail className="mr-2 h-4 w-4" />
            Email Receipt
          </Button>
          <Button variant="outline">
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button variant="outline">
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Receipt Content */}
          <Card className="lg:col-span-2 p-8">
            {/* Merchant Info */}
            <div className="text-center mb-8 pb-8 border-b">
              <h2 className="text-2xl font-bold mb-2">{receipt.merchant.name}</h2>
              <p className="text-muted-foreground">{receipt.merchant.address}</p>
              <p className="text-muted-foreground">{receipt.merchant.phone}</p>
              <p className="text-muted-foreground">{receipt.merchant.email}</p>
            </div>

            {/* Transaction Info */}
            <div className="grid md:grid-cols-2 gap-6 mb-8 pb-8 border-b">
              <div>
                <h3 className="font-semibold mb-3">Customer Information</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Name:</span>
                    <span className="ml-2 font-medium">{receipt.customer}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Email:</span>
                    <span className="ml-2 font-medium">{receipt.email}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Phone:</span>
                    <span className="ml-2 font-medium">{receipt.phone}</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-3">Transaction Details</h3>
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Date:</span>
                    <span className="ml-2 font-medium">{receipt.date}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Time:</span>
                    <span className="ml-2 font-medium">{receipt.time}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Payment:</span>
                    <span className="ml-2 font-medium">{receipt.paymentMethod}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Items */}
            <div className="mb-8">
              <h3 className="font-semibold mb-4">Items</h3>
              <div className="space-y-3">
                {receipt.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-3 border-b">
                    <div className="flex-1">
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-muted-foreground">Qty: {item.quantity} × {item.price}</p>
                    </div>
                    <p className="font-semibold">{item.total}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Totals */}
            <div className="space-y-3 pt-4 border-t">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-medium">{receipt.subtotal}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tax</span>
                <span className="font-medium">{receipt.tax}</span>
              </div>
              <div className="flex justify-between text-xl font-bold pt-3 border-t">
                <span>Total</span>
                <span className="text-primary">{receipt.total}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
              <p>Thank you for your business!</p>
              <p className="mt-2">This is a digitally generated receipt.</p>
            </div>
          </Card>

          {/* QR Code and Additional Info */}
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-4 text-center">Receipt QR Code</h3>
              <div className="flex justify-center mb-4">
                <div className="bg-white p-4 rounded-lg">
                  <QRCodeSVG
                    value={`https://digireceipt.app/receipt/${receipt.id}`}
                    size={180}
                    level="H"
                  />
                </div>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                Scan to verify and view receipt details
              </p>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Security Information</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-muted-foreground mb-1">Encryption</p>
                  <p className="font-medium">AES-256</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Verification</p>
                  <p className="font-medium">Blockchain-verified</p>
                </div>
                <div>
                  <p className="text-muted-foreground mb-1">Secure Link</p>
                  <p className="font-medium text-xs break-all text-primary">
                    https://digireceipt.app/v/{receipt.id}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ReceiptDetail;
