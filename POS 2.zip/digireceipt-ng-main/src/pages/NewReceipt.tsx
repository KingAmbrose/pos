import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import DashboardNav from "@/components/DashboardNav";
import { useState } from "react";
import { toast } from "sonner";

const NewReceipt = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState([
    { id: 1, name: "", quantity: 1, price: "" }
  ]);

  const addItem = () => {
    setItems([...items, { id: Date.now(), name: "", quantity: 1, price: "" }]);
  };

  const removeItem = (id: number) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== id));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Receipt generated successfully!");
    setTimeout(() => navigate("/transactions"), 1000);
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <main className="container py-8 max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to="/dashboard">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">Create New Receipt</h1>
            <p className="text-muted-foreground">Generate a digital receipt for a transaction</p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Customer Information */}
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">Customer Information</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="customerName">Customer Name *</Label>
                    <Input id="customerName" placeholder="Enter customer name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerEmail">Email Address</Label>
                    <Input id="customerEmail" type="email" placeholder="customer@email.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="customerPhone">Phone Number</Label>
                    <Input id="customerPhone" type="tel" placeholder="+234 800 000 0000" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="paymentMethod">Payment Method *</Label>
                    <select 
                      id="paymentMethod" 
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      required
                    >
                      <option value="card">Card Payment</option>
                      <option value="transfer">Bank Transfer</option>
                      <option value="cash">Cash</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
              </Card>

              {/* Items */}
              <Card className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold">Items</h2>
                  <Button type="button" onClick={addItem} size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Item
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {items.map((item, index) => (
                    <div key={item.id} className="flex gap-3 items-start p-4 border rounded-lg">
                      <div className="flex-1 grid md:grid-cols-3 gap-3">
                        <div className="space-y-2">
                          <Label htmlFor={`item-name-${item.id}`}>Item Name</Label>
                          <Input 
                            id={`item-name-${item.id}`}
                            placeholder="Product name" 
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`item-qty-${item.id}`}>Quantity</Label>
                          <Input 
                            id={`item-qty-${item.id}`}
                            type="number" 
                            min="1"
                            defaultValue="1"
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`item-price-${item.id}`}>Price (₦)</Label>
                          <Input 
                            id={`item-price-${item.id}`}
                            type="number" 
                            min="0"
                            step="0.01"
                            placeholder="0.00" 
                            required 
                          />
                        </div>
                      </div>
                      {items.length > 1 && (
                        <Button 
                          type="button"
                          variant="outline" 
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          className="mt-8"
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </Card>

              {/* Additional Details */}
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">Additional Details</h2>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <textarea 
                      id="notes"
                      className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      placeholder="Add any additional notes or comments..."
                    />
                  </div>
                </div>
              </Card>
            </div>

            {/* Summary */}
            <div className="space-y-6">
              <Card className="p-6 sticky top-24">
                <h2 className="text-xl font-semibold mb-4">Summary</h2>
                <div className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="font-medium">₦0.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Tax (0%)</span>
                      <span className="font-medium">₦0.00</span>
                    </div>
                    <div className="pt-3 border-t">
                      <div className="flex justify-between">
                        <span className="font-semibold">Total</span>
                        <span className="text-xl font-bold text-primary">₦0.00</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t space-y-3">
                    <Button type="submit" className="w-full">
                      Generate Receipt
                    </Button>
                    <Link to="/dashboard" className="block">
                      <Button type="button" variant="outline" className="w-full">
                        Cancel
                      </Button>
                    </Link>
                  </div>

                  <div className="pt-4 border-t text-sm text-muted-foreground">
                    <p className="mb-2">Receipt will be sent to:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>Customer email (if provided)</li>
                      <li>Customer phone via SMS</li>
                      <li>Stored in transaction history</li>
                    </ul>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
};

export default NewReceipt;
