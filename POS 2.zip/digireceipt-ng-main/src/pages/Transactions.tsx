import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Receipt, Search, Filter, Download, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import DashboardNav from "@/components/DashboardNav";

const Transactions = () => {
  const transactions = [
    { id: "TXN-001", customer: "Chidi Okeke", email: "chidi@email.com", amount: "₦15,500", date: "Jan 15, 2025", time: "14:30", status: "completed" },
    { id: "TXN-002", customer: "Amina Bello", email: "amina@email.com", amount: "₦8,200", date: "Jan 15, 2025", time: "14:15", status: "completed" },
    { id: "TXN-003", customer: "Tunde Williams", email: "tunde@email.com", amount: "₦22,750", date: "Jan 15, 2025", time: "13:58", status: "completed" },
    { id: "TXN-004", customer: "Ngozi Eze", email: "ngozi@email.com", amount: "₦4,100", date: "Jan 15, 2025", time: "13:20", status: "completed" },
    { id: "TXN-005", customer: "Ibrahim Musa", email: "ibrahim@email.com", amount: "₦12,300", date: "Jan 15, 2025", time: "12:45", status: "completed" },
    { id: "TXN-006", customer: "Ada Okafor", email: "ada@email.com", amount: "₦18,900", date: "Jan 14, 2025", time: "18:20", status: "completed" },
    { id: "TXN-007", customer: "Yusuf Ahmed", email: "yusuf@email.com", amount: "₦6,750", date: "Jan 14, 2025", time: "17:55", status: "completed" },
    { id: "TXN-008", customer: "Blessing Adeyemi", email: "blessing@email.com", amount: "₦31,200", date: "Jan 14, 2025", time: "16:40", status: "completed" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <main className="container py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Transactions</h1>
            <p className="text-muted-foreground">View and manage all transaction receipts</p>
          </div>
          <Link to="/transactions/new">
            <Button>
              <Receipt className="mr-2 h-4 w-4" />
              New Receipt
            </Button>
          </Link>
        </div>

        {/* Filters and Search */}
        <Card className="p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by transaction ID, customer name, or email..." className="pl-10" />
            </div>
            <Button variant="outline">
              <Calendar className="mr-2 h-4 w-4" />
              Date Range
            </Button>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </Card>

        {/* Transactions Table */}
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-4 font-semibold">Transaction ID</th>
                  <th className="text-left p-4 font-semibold">Customer</th>
                  <th className="text-left p-4 font-semibold">Amount</th>
                  <th className="text-left p-4 font-semibold">Date & Time</th>
                  <th className="text-left p-4 font-semibold">Status</th>
                  <th className="text-left p-4 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((transaction) => (
                  <tr key={transaction.id} className="border-b hover:bg-secondary/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <Receipt className="h-4 w-4 text-primary" />
                        </div>
                        <span className="font-medium">{transaction.id}</span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{transaction.customer}</p>
                        <p className="text-sm text-muted-foreground">{transaction.email}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold">{transaction.amount}</span>
                    </td>
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{transaction.date}</p>
                        <p className="text-sm text-muted-foreground">{transaction.time}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                        {transaction.status}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <Link to={`/transactions/${transaction.id}`}>
                        <Button variant="outline" size="sm">View</Button>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="flex items-center justify-between p-4 border-t">
            <p className="text-sm text-muted-foreground">Showing 1-8 of 156 transactions</p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled>Previous</Button>
              <Button variant="outline" size="sm">Next</Button>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
};

export default Transactions;
