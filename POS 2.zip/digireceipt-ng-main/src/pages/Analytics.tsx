import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, DollarSign, Receipt, Users, Calendar } from "lucide-react";
import DashboardNav from "@/components/DashboardNav";
import analyticsImage from "@/assets/analytics-illustration.jpg";

const Analytics = () => {
  const metrics = [
    { label: "Total Revenue", value: "₦3.2M", change: "+18%", trend: "up", period: "This month" },
    { label: "Total Receipts", value: "4,523", change: "+12%", trend: "up", period: "This month" },
    { label: "Unique Customers", value: "1,847", change: "+25%", trend: "up", period: "This month" },
    { label: "Avg. Transaction", value: "₦707", change: "-5%", trend: "down", period: "This month" },
  ];

  const topProducts = [
    { name: "Product A", sales: "₦850K", count: 245, percentage: 85 },
    { name: "Product B", sales: "₦620K", count: 189, percentage: 68 },
    { name: "Product C", sales: "₦510K", count: 156, percentage: 55 },
    { name: "Product D", sales: "₦380K", count: 112, percentage: 42 },
  ];

  return (
    <div className="min-h-screen bg-background">
      <DashboardNav />
      
      <main className="container py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Analytics</h1>
            <p className="text-muted-foreground">Insights into your business performance</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Calendar className="mr-2 h-4 w-4" />
              Last 30 Days
            </Button>
            <Button variant="outline">Export Report</Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          {metrics.map((metric) => {
            const Icon = metric.trend === "up" ? TrendingUp : TrendingDown;
            return (
              <Card key={metric.label} className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="rounded-lg bg-primary/10 p-3">
                    {metric.label.includes("Revenue") && <DollarSign className="h-5 w-5 text-primary" />}
                    {metric.label.includes("Receipts") && <Receipt className="h-5 w-5 text-primary" />}
                    {metric.label.includes("Customers") && <Users className="h-5 w-5 text-primary" />}
                    {metric.label.includes("Transaction") && <TrendingUp className="h-5 w-5 text-primary" />}
                  </div>
                  <div className="flex items-center gap-1">
                    <Icon className={`h-4 w-4 ${metric.trend === 'up' ? 'text-success' : 'text-destructive'}`} />
                    <span className={`text-sm font-medium ${metric.trend === 'up' ? 'text-success' : 'text-destructive'}`}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <p className="text-2xl font-bold">{metric.value}</p>
                  <p className="text-xs text-muted-foreground">{metric.period}</p>
                </div>
              </Card>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          {/* Revenue Chart Placeholder */}
          <Card className="lg:col-span-2 p-6">
            <h2 className="text-xl font-semibold mb-6">Revenue Trends</h2>
            <div className="aspect-video rounded-lg overflow-hidden">
              <img 
                src={analyticsImage} 
                alt="Analytics dashboard showing transaction trends and revenue charts" 
                className="w-full h-full object-cover"
              />
            </div>
          </Card>

          {/* Top Products */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-6">Top Products</h2>
            <div className="space-y-6">
              {topProducts.map((product, index) => (
                <div key={index}>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-muted-foreground">{product.count} sales</p>
                    </div>
                    <p className="font-semibold">{product.sales}</p>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full transition-all" 
                      style={{ width: `${product.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Additional Stats */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Payment Methods</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Card Payment</span>
                <span className="font-semibold">68%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Bank Transfer</span>
                <span className="font-semibold">22%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Cash</span>
                <span className="font-semibold">10%</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold mb-4">Peak Hours</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">12:00 - 14:00</span>
                <span className="font-semibold">35%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">17:00 - 19:00</span>
                <span className="font-semibold">28%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">10:00 - 12:00</span>
                <span className="font-semibold">20%</span>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
            <h3 className="font-semibold mb-2">Customer Retention</h3>
            <div className="mt-4">
              <div className="text-4xl font-bold text-primary mb-2">82%</div>
              <p className="text-muted-foreground">Repeat customer rate</p>
              <div className="mt-4 flex items-center gap-2 text-success">
                <TrendingUp className="h-4 w-4" />
                <span className="text-sm font-medium">+15% from last month</span>
              </div>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default Analytics;
